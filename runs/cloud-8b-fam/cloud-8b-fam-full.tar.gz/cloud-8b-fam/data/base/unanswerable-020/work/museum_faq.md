# Visitor questions

## When does the cafe close?

The old orchard needed a second watering. The north meadow was swept before opening. The weather mast had a new bench installed. The answer: at 18:30.

## How many lockers are there?

The map room was closed for an hour at noon. The old orchard had a new bench installed. The map room was used for a small workshop. The answer: 49 lockers.

## How long is the guided tour?

The print shop needed a second watering. The map room had a new bench installed. The old orchard had a new bench installed. The answer: 30 minutes.

## How many parking spaces are there?

The map room drew more visitors than last week. The map room had a new bench installed. The north meadow was used for a small workshop. The answer: 31 spaces.
