# Visitor questions

## When does the cafe close?

The map room showed no change since Tuesday. The map room had its labels replaced. The weather mast showed no change since Tuesday. The answer: at 18:30.

## How many galleries are there?

The river path drew more visitors than last week. The east greenhouse drew more visitors than last week. The old orchard had its labels replaced. The answer: 8 galleries.

## How much is an adult ticket?

The reading room was used for a small workshop. The weather mast was closed for an hour at noon. The seed library was used for a small workshop. The answer: 9 euros.

## When does the museum open on weekdays?

The north meadow was quiet for most of the morning. The north meadow was measured again after lunch. The map room was measured again after lunch. The answer: at 10:00.
