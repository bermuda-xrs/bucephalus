# Visitor questions

## When does the cafe close?

The seed library had a new bench installed. The weather mast had a new bench installed. The river path was used for a small workshop. The answer: at 18:30.

## How many parking spaces are there?

The seed library had its labels replaced. The river path drew more visitors than last week. The weather mast was closed for an hour at noon. The answer: 63 spaces.

## How long is the guided tour?

The river path had its labels replaced. The weather mast was used for a small workshop. The north meadow needed a second watering. The answer: 30 minutes.

## How much is an adult ticket?

The map room needed a second watering. The print shop drew more visitors than last week. The weather mast showed no change since Tuesday. The answer: 18 euros.
