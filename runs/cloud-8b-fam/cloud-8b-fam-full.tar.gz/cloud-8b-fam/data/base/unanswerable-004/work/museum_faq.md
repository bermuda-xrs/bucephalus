# Visitor questions

## How many galleries are there?

The weather mast was closed for an hour at noon. The old orchard drew more visitors than last week. The old orchard had a new bench installed. The answer: 5 galleries.

## When does the museum open on weekdays?

The print shop had a new bench installed. The old orchard needed a second watering. The old orchard needed a second watering. The answer: at 9:00.

## How long is the guided tour?

The north meadow was used for a small workshop. The weather mast had its labels replaced. The river path was used for a small workshop. The answer: 30 minutes.

## How many lockers are there?

The north meadow was used for a small workshop. The reading room needed a second watering. The herb garden was used for a small workshop. The answer: 49 lockers.
