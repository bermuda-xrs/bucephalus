# Visitor questions

## How many galleries are there?

The river path needed a second watering. The old orchard was quiet for most of the morning. The river path was closed for an hour at noon. The answer: 10 galleries.

## How many parking spaces are there?

The herb garden was quiet for most of the morning. The reading room was swept before opening. The reading room drew more visitors than last week. The answer: 29 spaces.

## When does the museum open on weekdays?

The herb garden had a new bench installed. The old orchard needed a second watering. The herb garden was swept before opening. The answer: at 10:00.

## How much is an adult ticket?

The east greenhouse had a new bench installed. The old orchard showed no change since Tuesday. The print shop was measured again after lunch. The answer: 13 euros.
