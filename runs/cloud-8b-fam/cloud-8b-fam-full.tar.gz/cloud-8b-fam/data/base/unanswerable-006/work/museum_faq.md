# Visitor questions

## How many lockers are there?

The weather mast showed no change since Tuesday. The herb garden was measured again after lunch. The herb garden had its labels replaced. The answer: 78 lockers.

## How much is an adult ticket?

The print shop needed a second watering. The east greenhouse was quiet for most of the morning. The print shop had a new bench installed. The answer: 16 euros.

## When does the cafe close?

The old orchard had a new bench installed. The north meadow was closed for an hour at noon. The print shop was swept before opening. The answer: at 17:30.

## How long is the guided tour?

The east greenhouse had a new bench installed. The print shop was quiet for most of the morning. The old orchard had its labels replaced. The answer: 45 minutes.
