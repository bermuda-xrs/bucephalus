# Visitor questions

## When does the cafe close?

The east greenhouse was quiet for most of the morning. The weather mast drew more visitors than last week. The weather mast was closed for an hour at noon. The answer: at 18:30.

## How long is the guided tour?

The herb garden showed no change since Tuesday. The herb garden showed no change since Tuesday. The map room was quiet for most of the morning. The answer: 60 minutes.

## When does the museum open on weekdays?

The north meadow was swept before opening. The seed library was used for a small workshop. The print shop had a new bench installed. The answer: at 8:00.

## How many galleries are there?

The map room was used for a small workshop. The herb garden drew more visitors than last week. The north meadow showed no change since Tuesday. The answer: 4 galleries.
