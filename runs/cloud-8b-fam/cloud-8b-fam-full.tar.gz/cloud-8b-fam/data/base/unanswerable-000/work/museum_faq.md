# Visitor questions

## How much is an adult ticket?

The old orchard needed a second watering. The print shop was closed for an hour at noon. The north meadow was closed for an hour at noon. The answer: 19 euros.

## How long is the guided tour?

The herb garden had a new bench installed. The seed library was quiet for most of the morning. The north meadow drew more visitors than last week. The answer: 60 minutes.

## How many lockers are there?

The north meadow had its labels replaced. The east greenhouse was closed for an hour at noon. The herb garden was used for a small workshop. The answer: 81 lockers.

## How many parking spaces are there?

The river path was used for a small workshop. The old orchard was swept before opening. The weather mast needed a second watering. The answer: 87 spaces.
