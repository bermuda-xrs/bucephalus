# Visitor questions

## How much is an adult ticket?

The east greenhouse drew more visitors than last week. The map room drew more visitors than last week. The weather mast was closed for an hour at noon. The answer: 13 euros.

## When does the cafe close?

The weather mast was measured again after lunch. The weather mast had a new bench installed. The north meadow had a new bench installed. The answer: at 17:30.

## How many lockers are there?

The east greenhouse needed a second watering. The river path was measured again after lunch. The herb garden was used for a small workshop. The answer: 87 lockers.

## How many galleries are there?

The old orchard drew more visitors than last week. The seed library needed a second watering. The map room was used for a small workshop. The answer: 4 galleries.
