# Visitor questions

## How many lockers are there?

The reading room was used for a small workshop. The east greenhouse drew more visitors than last week. The seed library needed a second watering. The answer: 72 lockers.

## How many parking spaces are there?

The old orchard was used for a small workshop. The reading room was swept before opening. The river path needed a second watering. The answer: 59 spaces.

## How long is the guided tour?

The east greenhouse was quiet for most of the morning. The print shop was quiet for most of the morning. The weather mast was closed for an hour at noon. The answer: 45 minutes.

## How much is an adult ticket?

The east greenhouse was used for a small workshop. The herb garden was quiet for most of the morning. The herb garden showed no change since Tuesday. The answer: 17 euros.
