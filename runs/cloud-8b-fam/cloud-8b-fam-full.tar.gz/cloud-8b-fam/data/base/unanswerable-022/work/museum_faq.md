# Visitor questions

## How long is the guided tour?

The herb garden needed a second watering. The print shop drew more visitors than last week. The seed library had a new bench installed. The answer: 75 minutes.

## How much is an adult ticket?

The river path was used for a small workshop. The print shop needed a second watering. The reading room had its labels replaced. The answer: 7 euros.

## When does the museum open on weekdays?

The weather mast had its labels replaced. The east greenhouse had its labels replaced. The reading room was quiet for most of the morning. The answer: at 9:00.

## How many parking spaces are there?

The reading room showed no change since Tuesday. The east greenhouse was measured again after lunch. The north meadow was measured again after lunch. The answer: 22 spaces.
