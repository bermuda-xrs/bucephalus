# Visitor questions

## When does the cafe close?

The river path drew more visitors than last week. The herb garden had a new bench installed. The seed library drew more visitors than last week. The answer: at 18:30.

## How many lockers are there?

The seed library had a new bench installed. The seed library was closed for an hour at noon. The north meadow was used for a small workshop. The answer: 30 lockers.

## How many galleries are there?

The old orchard was measured again after lunch. The old orchard had a new bench installed. The north meadow was used for a small workshop. The answer: 4 galleries.

## How long is the guided tour?

The east greenhouse was closed for an hour at noon. The reading room showed no change since Tuesday. The map room was measured again after lunch. The answer: 30 minutes.
