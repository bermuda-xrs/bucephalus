# Visitor questions

## How many parking spaces are there?

The old orchard had its labels replaced. The seed library had a new bench installed. The print shop showed no change since Tuesday. The answer: 88 spaces.

## When does the museum open on weekdays?

The seed library had its labels replaced. The seed library was measured again after lunch. The map room was used for a small workshop. The answer: at 8:00.

## When does the cafe close?

The print shop needed a second watering. The herb garden was measured again after lunch. The old orchard was closed for an hour at noon. The answer: at 16:30.

## How much is an adult ticket?

The river path had its labels replaced. The old orchard needed a second watering. The seed library needed a second watering. The answer: 10 euros.
