# Visitor questions

## When does the museum open on weekdays?

The weather mast was measured again after lunch. The reading room drew more visitors than last week. The print shop was quiet for most of the morning. The answer: at 8:00.

## How long is the guided tour?

The north meadow was measured again after lunch. The weather mast was swept before opening. The herb garden was swept before opening. The answer: 60 minutes.

## How many galleries are there?

The herb garden had its labels replaced. The print shop had its labels replaced. The river path was quiet for most of the morning. The answer: 12 galleries.

## When does the cafe close?

The print shop was swept before opening. The river path was swept before opening. The east greenhouse was measured again after lunch. The answer: at 17:30.
